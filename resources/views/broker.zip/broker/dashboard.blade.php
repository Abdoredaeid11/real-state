@extends('broker.layout.master')

@section('content')
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">
        {{ $broker->name }}
    </h1>

    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm border-left-primary h-100 py-2">
                <div class="card-body">
                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                        {{ __('admin.dashboard_stats.total_properties') }}
                    </div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $totalProperties }}</div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center shadow-sm border-left-info h-100 py-2">
                <div class="card-body">
                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                        {{ __('admin.dashboard_stats.total_reservations') }}
                    </div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $totalReservations }}</div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center shadow-sm border-left-warning h-100 py-2">
                <div class="card-body">
                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                        {{ __('admin.dashboard_stats.open_leads') }}
                    </div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $openLeads }}</div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center shadow-sm border-left-success h-100 py-2">
                <div class="card-body">
                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                        {{ __('admin.dashboard_stats.total_paid_amount') }}
                    </div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                        ${{ number_format($totalPaidAmount, 2) }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

