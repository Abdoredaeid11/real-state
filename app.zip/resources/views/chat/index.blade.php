@extends('layouts.master')

@section('content')
<div class="container ptb-120">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <h2 class="mb-4 text-center">Support Chat</h2>
            <p class="text-center">Use the chat icon at the bottom of the page to talk with support.</p>
        </div>
    </div>
</div>
@endsection

