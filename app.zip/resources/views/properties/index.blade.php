@extends('layouts.master')
@section('content')
    <!-- Start Page Banner Area -->
    <div class="page-banner-area">
        <div class="container">
            <div class="page-banner-content">
                <h2>Property Grid</h2>
                <ul class="list">
                    <li>
                        <a href="index.html">Home</a>
                    </li>
                    <li>Property Grid</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Page Banner Area -->

    <!-- Start Properties Area -->
    <div class="properties-area ptb-120">
        <div class="container">
            <div class="row justify-content-center" data-cues="slideInUp">
                @foreach ($properties as $property)
                    <div class="col-xl-4 col-md-6">
                        <div class="properties-item">
                            <div class="properties-image">
                                <a href="property-details.html">
                                    <img src="{{ $property->images->first() ? asset('storage/' . $property->images->first()->image) : asset('assets/images/properties/properties1.jpg') }}"
                                        alt="image">
                                </a>
                                <ul class="action">
                                    <li>
                                        <a href="property-grid.html" class="featured-btn">Featured</a>
                                    </li>
                                    <li>
                                        <div class="media">
                                            <span><i class="ri-vidicon-fill"></i></span>
                                            <span><i class="ri-image-line"></i></span>
                                        </div>
                                    </li>
                                </ul>
                                <ul class="link-list">
                                    <li>
                                        <a href="property-grid.html" class="link-btn">Apartment</a>
                                    </li>
                                    <li>
                                        <a href="property-grid.html" class="link-btn">For Sale</a>
                                    </li>
                                </ul>
                                <ul class="info-list">
                                    <li>
                                        <div class="icon">
                                            <img src="{{ asset('assets/images/properties/bed.svg') }}" alt="bed">
                                        </div>
                                        <span>{{ $property->bedrooms }}</span>
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <img src="{{ asset('assets/images/properties/bathroom.svg') }}" alt="bathroom">
                                        </div>
                                        <span>{{ $property->bathrooms }}</span>
                                    </li>

                                    <li>
                                        <div class="icon">
                                            <img src="{{ asset('assets/images/properties/area.svg') }}" alt="area">
                                        </div>
                                        <span>{{ $property->area }}</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="properties-content">
                                <div class="top">
                                    <div class="title">
                                        <h3>
                                            <a href="{{route('property.show',$property->id)}}">Vacation Homes</a>
                                        </h3>
                                        <span>{{ $property->address . ' , ' . $property->city }}</span>
                                    </div>
                                    <div class="price">{{ $property->price }}$</div>
                                </div>
                                <div class="bottom">
                                    <div class="user">
                                        <img src="{{ asset('assets/images/user/user1.png') }}" alt="user">
                                        <a href="agent-profile.html">{{ $property->broker->name ?? 'No Broker' }}</a>
                                    </div>
                                    <ul class="group-info">
                                        <li>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="ri-share-line"></i>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li>
                                                        <a href="https://www.facebook.com/" target="_blank">
                                                            <i class="ri-facebook-fill"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="https://twitter.com/" target="_blank">
                                                            <i class="ri-twitter-x-line"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.instagram.com/" target="_blank">
                                                            <i class="ri-instagram-fill"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="https://bd.linkedin.com/" target="_blank">
                                                            <i class="ri-linkedin-fill"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
<li>
    <button type="button" data-bs-toggle="tooltip" data-bs-placement="top" title="Call">
        <i class="ri-phone-line"></i>
    </button>
</li>
<li>
    <button type="button" data-bs-toggle="tooltip" data-bs-placement="top" title="WhatsApp">
        <i class="ri-whatsapp-line"></i>
    </button>
</li>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
                {{ $properties->links() }}

            </div>
        </div>
    </div>
    <!-- End Properties Area -->



    <!-- Start Subscribe Area -->
    <div class="subscribe-wrap-area">
        <div class="container" data-cues="slideInUp">
            <div class="subscribe-wrap-inner-area">
                <div class="subscribe-content">
                    <h2>Subscribe To Our Newsletter</h2>
                    <form class="subscribe-form">
                        <input type="search" class="form-control" placeholder="Enter your email">
                        <button type="submit" class="default-btn">Subscribe</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
