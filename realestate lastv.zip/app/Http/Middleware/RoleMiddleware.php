<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RoleMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, ...$roles): Response
    {
        if (!auth()->check()) {
            if (in_array('admin', $roles, true)) {
                return redirect()->route('admin.login.form');
            }

            return redirect()->route('login');
        }

        if (!in_array(auth()->user()->role, $roles)) {
            if (in_array('admin', $roles, true)) {
                return redirect()->route('admin.login.form');
            }

            abort(403, 'Not allowed');
        }

        return $next($request);
    }
}
