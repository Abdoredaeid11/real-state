<?php

namespace App\Http\Controllers\Broker;

use App\Http\Controllers\Controller;
use App\Models\Property;
use App\Models\Reservation;
use App\Models\Payment;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $broker = Auth::user();

        $totalProperties = Property::where('broker_id', $broker->id)->count();

        $reservationQuery = Reservation::where('broker_id', $broker->id);

        $totalReservations = (clone $reservationQuery)->count();

        $openLeads = (clone $reservationQuery)
            ->whereIn('status', ['pending', 'contacted'])
            ->count();

        $upcomingCheckins = (clone $reservationQuery)
            ->whereNotNull('check_in')
            ->whereDate('check_in', '>=', now()->toDateString())
            ->whereDate('check_in', '<=', now()->addDays(7)->toDateString())
            ->count();

        $reservationIds = (clone $reservationQuery)->pluck('id');

        $totalPaidAmount = Payment::whereIn('reservation_id', $reservationIds)
            ->where('status', 'paid')
            ->sum('amount');

        return view('broker.dashboard', compact(
            'broker',
            'totalProperties',
            'totalReservations',
            'openLeads',
            'upcomingCheckins',
            'totalPaidAmount',
        ));
    }
}

