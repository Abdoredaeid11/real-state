<?php

namespace App\Http\Controllers\Broker;

use App\Http\Controllers\Controller;
use App\Models\Property;
use App\Models\PropertyType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PropertyController extends Controller
{
    public function index(Request $request)
    {
        $brokerId = Auth::id();

        $properties = Property::with(['type', 'category', 'images', 'broker'])
            ->where('broker_id', $brokerId)
            ->typeId($request->property_type_id)
            ->city($request->city)
            ->priceMin($request->price_min)
            ->priceMax($request->price_max)
            ->search($request->search)
            ->status($request->status)
            ->when($request->type, fn($q) => $q->where('type', $request->type))
            ->orderByDesc('created_at')
            ->paginate(10)
            ->appends($request->query());

        $types = PropertyType::select('id', 'name', 'name_ar')->get();

        return view('broker.properties.index', compact('properties', 'types'));
    }
}

